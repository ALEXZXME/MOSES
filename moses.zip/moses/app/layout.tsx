import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Project Moses',
  description: 'You are promised by Project Moses',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}