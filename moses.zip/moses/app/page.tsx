'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface FormData {
  email: string;
  role: string;
  contribution: string;
}

export default function Home() {
  const [visible, setVisible] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [maskSize, setMaskSize] = useState(0)
  const [formData, setFormData] = useState<FormData>({
    email: '',
    role: '',
    contribution: ''
  })
  const [darkness, setDarkness] = useState(0)

  useEffect(() => {
    setMaskSize(Math.max(window.innerWidth, window.innerHeight))

    const handleScroll = () => {
      const scrolled = window.scrollY > 100
      setVisible(scrolled)

      const maxScroll = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercentage = window.scrollY / maxScroll
      const newSize = 300 + (Math.max(window.innerWidth, window.innerHeight) - 300) * scrollPercentage
      setMaskSize(newSize)

      const newDarkness = Math.min(scrollPercentage * 0.7, 0.7)
      setDarkness(newDarkness)

      const neonEffect = document.querySelector('.neon-effect') as HTMLElement;
      if (neonEffect) {
        neonEffect.style.width = `${newSize * 2}px`;
        neonEffect.style.height = `${newSize * 2}px`;
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Form submitted:', formData)
    setIsModalOpen(false)
  }

  return (
    <div className="min-h-[200vh] relative overflow-hidden">
      {/* 组件的其余代码保持不变 */}
    </div>
  )
}